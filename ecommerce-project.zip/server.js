
const express=require('express');
const app=express();
app.use(express.static('public'));
app.get('/products',(req,res)=>res.sendFile(__dirname+'/products.json'));
app.listen(3000,()=>console.log('Running on 3000'));
