
let allProducts=[],cart=[],total=0;
fetch('/products').then(r=>r.json()).then(d=>{allProducts=d;render(d);});
function render(data){
document.getElementById('products').innerHTML=data.map(p=>
`<div class="card"><h3>${p.name}</h3><p>₹${p.price}</p>
<button onclick="addToCart('${p.name}',${p.price})">Add</button></div>`).join('');
}
function addToCart(name,price){
cart.push(name); total+=price;
document.getElementById('cart').innerHTML=cart.map(i=>`<li>${i}</li>`).join('');
document.getElementById('total').innerText='Total: ₹'+total;
}
document.addEventListener('input',e=>{
if(e.target.id==='search'){
render(allProducts.filter(p=>p.name.toLowerCase().includes(e.target.value.toLowerCase())));
}});
